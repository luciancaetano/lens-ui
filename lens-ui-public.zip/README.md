# LensUi Design System
Este é um fork de um design system pessoal que eu venho trabalhando no mesmo a algum tempo.
Nesta versão pública eu venho trazer algumas melhorias bem como simplificações no design.

# Components
- Badge
- Breadcrumbs
- Button
- ButtonGroup
- Callout
- Card
- Checkbox
- DateInput
- Divider
- DropdownMenu
- FormFooter
- FormGroup
- Icon
- Layout
- List
- Loader
- Markdown
- MaskedInput
- MenuList
- MessageBox
- Modal
- ModalContent
- ModalFooter
- ModalHeader
- ProgressBar
- RadioGroup
- Select
- Switch
- Table
- Tabs
- TextInput
- Toast

#Providers
- LensProvider

# TODO
- Implement visual regression tests
- Write documentation or Write documented storybook's