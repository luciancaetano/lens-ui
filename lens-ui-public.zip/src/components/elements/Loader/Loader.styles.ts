import styled from 'styled-components';

export const LoaderContainer = styled.div<{loaderRem: number}>`

  --loader-width: ${(props) => props.loaderRem}rem;

  display: flex;
  overflow: hidden;
  font-size: .65625rem;
  border-radius: .25rem;
  position: relative;
  width: var(--loader-width);
  height: var(--loader-width);

  .lens-ui-loader-content-container {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .content-container {
    display: flex;
  }
`;
