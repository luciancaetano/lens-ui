import AppLayout from './AppLayout/AppLayout';
import Content from './Content/Content';
import Sidebar from './Sidebar/Sidebar';

export default { AppLayout, Content, Sidebar };
