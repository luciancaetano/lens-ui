import { IPropsWithClassName, IPropsWithId, ITestableProps } from '../../../types';

export interface IDividerProps extends IPropsWithClassName, ITestableProps, IPropsWithId {

}
