import {
  IPropsWithClassName, IPropsWithId, ITestableProps,
} from '../../../types';

export interface IModalContentProps extends ITestableProps, IPropsWithClassName, IPropsWithId {

}
