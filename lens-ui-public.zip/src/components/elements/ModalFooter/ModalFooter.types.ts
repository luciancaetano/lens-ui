import {
  IPropsWithClassName, IPropsWithId, ITestableProps,
} from '../../../types';

export interface IModalFooterProps extends ITestableProps, IPropsWithClassName, IPropsWithId {

}
