jest.mock('../src/hooks/use-internal-lens-locale', () => () => [(v) => v, () => {}]);
